Exercise 1: 

    Read Total profit of all months and show it using a line plot
    Total profit data provided for each month. Generated line plot must include the following properties: –
    X label name = Month Number
    Y label name = Total profit

Exercise 2: 

    Get total profit of all months and show line plot with the following Style properties
    Generated line plot must include following Style properties: –
    Line Style dotted and Line-color should be red
    Show legend at the lower right location.
    X label name = Month Number
    Y label name = Sold units number
    Add a circle marker.
    Line marker color as read
    Line width should be 3




```python
import pandas as pd 
data=pd.read_csv("company_sales_data.csv")
df=pd.DataFrame(data)
```


```python
import matplotlib.pyplot as plt
plt.plot(df['month_number'],df['total_profit'],linewidth=3,linestyle='--',c='r',marker='o',markerfacecolor='black', 
         markeredgecolor='r',markersize=10)
plt.grid()
plt.legend(['Profit Data Of Last Year'],loc='lower right')
plt.xlabel('Month Number',color='r')
plt.ylabel('Total Profit',color='r')
plt.title('Company Profit Per Month',c='g',fontsize='14')
```




    Text(0.5, 1.0, 'Company Profit Per Month')




    
![png](output_2_1.png)
    


Exercise 3:

    Read all product sales data and show it  using a multiline plot
    Display the number of units sold per month for each product using multiline plots. (i.e., Separate Plotline for each product ).


```python
plt.plot(df['month_number'],df['facecream'],linewidth=3,marker='o')
plt.plot(df['month_number'],df['facewash'],marker='o')
plt.plot(df['month_number'],df['toothpaste'],marker='o')
plt.plot(df['month_number'],df['bathingsoap'],linewidth=3,marker='o')
plt.plot(df['month_number'],df['shampoo'],marker='o')
plt.plot(df['month_number'],df['moisturizer'],linewidth=3,marker='o')
plt.grid()

plt.xlabel('Month number')
plt.ylabel('Sales')
plt.title('SALES DATA')

plt.legend(['facecream','facewash','toothpaste','bathingsoap','shampoo','moisturizer'])
```




    <matplotlib.legend.Legend at 0x2a641c62850>




    
![png](output_4_1.png)
    


Exercise 4: 

    Read toothpaste sales data of each month and show it using a scatter plot
    Also, add a grid in the plot. gridline style should “–“.


```python
plt.scatter(df['month_number'],df['toothpaste'],c=df['toothpaste'],cmap='Wistia')
plt.colorbar(label="Sales")
plt.grid()
plt.xlabel('Month number')
plt.ylabel('Sales')
plt.title('TOOTH-PASTE SALES DATA')
plt.legend(['Tooth Paste Sales Data'])
```




    <matplotlib.legend.Legend at 0x2a63ea41a90>




    
![png](output_6_1.png)
    


Exercise 5: 

    Read face cream and facewash product sales data and show it using the bar chart
    The bar chart should display the number of units sold per month for each product. Add a separate bar for each product in the same chart.


```python

plt.bar(df['month_number']-0.4,df['facecream'],width=0.4,label='facecream')
plt.bar(df['month_number'],df['facewash'],width=0.4,label='facewash')
#plt.grid() 
plt.title('Sales Data Comparison')
plt.xlabel('Month Number')
plt.ylabel('Sales')
plt.legend()
```




    <matplotlib.legend.Legend at 0x2a6454fe990>




    
![png](output_8_1.png)
    


Exercise 7: 

    Read the total profit of each month and show it using the histogram to see the most common profit ranges


```python
profit_range = [150000, 175000, 200000, 225000, 250000, 300000, 350000]
plt.hist(df['total_profit'],bins=profit_range)
plt.xlabel('profit_range')
plt.ylabel('Actual Profit In Dollar')
plt.title('Profit Data',c='r')
```




    Text(0.5, 1.0, 'Profit Data')




    
![png](output_10_1.png)
    


Exercise 8: 

    Calculate total sale data for last year for each product and show it using a Pie chart


```python
sales_data = [
    df['facecream'].sum(), 
    df['facewash'].sum(), 
    df['toothpaste'].sum(), 
    df['bathingsoap'].sum(), 
    df['shampoo'].sum(), 
    df['moisturizer'].sum()
]
labels = ['Face Cream', 'Face Wash', 'Toothpaste', 'Bathing Soap', 'Shampoo', 'Moisturizer']
plt.figure(figsize=(10,5))
plt.pie(sales_data, labels=labels, autopct='%1.1f%%',startangle=140)
plt.legend(labels,loc='upper right',bbox_to_anchor=(1.05, 1))
plt.tight_layout()
```


    
![png](output_12_0.png)
    



```python

```
